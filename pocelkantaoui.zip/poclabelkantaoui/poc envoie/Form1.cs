﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Net.NetworkInformation;

namespace pocenvoie
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort = new SerialPort();
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);

            // Configuration du port
            serialPort.BaudRate = 9600;
            serialPort.Parity = Parity.None;
            serialPort.DataBits = 8;
            serialPort.StopBits = StopBits.One;
            serialPort.Handshake = Handshake.None;

            serialPort.DataReceived += SerialPort_DataReceived;

        }

        private void ouvrir_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                if (!serialPort.IsOpen)
                {
                    serialPort.PortName = comboBox1.SelectedItem.ToString();
                    try
                    {
                        serialPort.Open();
                        MessageBox.Show("Port ouvert !");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur : " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Choisissez un port COM.");
            }











        }

        private void close_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
                MessageBox.Show("Port fermé.");
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void send_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                string message = textBox1Send.Text.Trim();
                if (!string.IsNullOrEmpty(message))
                {
                    serialPort.WriteLine(message);
                    comboBox1.Items.Add("Envoyé : " + message);
                    textBox1Send.Clear();
                }
            }
            else
            {
                MessageBox.Show("Port non ouvert !");
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serialPort.ReadLine();
            Invoke(new MethodInvoker(delegate
            {
                comboBox1.Items.Add("Reçu : " + data);
            }));
        }

    }
}
