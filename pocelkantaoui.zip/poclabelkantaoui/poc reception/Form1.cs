﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace pocreception
{
    public partial class Form1 : Form

    {
        private SerialPort serialPort = new SerialPort();
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem != null)
            {
                if (!serialPort.IsOpen)
                {
                    serialPort.PortName = comboBox1.SelectedItem.ToString();
                    try
                    {
                        serialPort.Open();
                        MessageBox.Show("Port ouvert !");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur : " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un port COM.");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
                MessageBox.Show("Port fermé.");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);

            // Configuration de base du port
            serialPort.BaudRate = 9600;
            serialPort.Parity = Parity.None;
            serialPort.DataBits = 8;
            serialPort.StopBits = StopBits.One;
            serialPort.Handshake = Handshake.None;

            // Gérer les données reçues
            serialPort.DataReceived += SerialPort_DataReceived;
        }
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = serialPort.ReadLine(); // Lecture ligne par ligne
                Invoke(new MethodInvoker(delegate
                {
                    textBox2.Text += data + Environment.NewLine;
                }));
            }
            catch (Exception ex)
            {
                Invoke(new MethodInvoker(delegate
                {
                    MessageBox.Show("Erreur de lecture : " + ex.Message);
                }));
            }
        }
        }
}
